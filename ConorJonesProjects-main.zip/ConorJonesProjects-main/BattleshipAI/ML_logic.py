from battleship_game import BattleshipGame

BattleshipGame().build_board()